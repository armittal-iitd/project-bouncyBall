var ball,img,paddle,img2;
function preload() {
  img=loadImage("ball.png");
  img2=loadImage("paddle.png");
}
function setup() {
  createCanvas(400, 400);
    
  ball=createSprite(200,200,20,20);
  ball.addImage("ball",img);
  ball.velocityX= -9
  paddle=createSprite(30,200,200,20);
  paddle.addImage("paddle",img2);
}

function draw() {
  background(205,153,0);
  
  edges=createEdgeSprites();
  
  randomVelocity();
  
  ball.bounceOff(paddle);
  ball.bounceOff(edges[1]);
  ball.bounceOff(edges[2])
  ball.bounceOff(edges[3])
                 
  if(keyDown(UP_ARROW))
  {
     paddle.y = paddle.y + -10
  }
  
  if(keyDown(DOWN_ARROW))
  {
     paddle.y = paddle.y+ 10
  }
  drawSprites();
  
}

function randomVelocity()
{
  numb=random(-3,20);
  
  ball.velocityY= numb
  

}

